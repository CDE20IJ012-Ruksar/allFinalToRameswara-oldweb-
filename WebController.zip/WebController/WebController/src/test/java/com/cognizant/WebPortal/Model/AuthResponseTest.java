package com.cognizant.WebPortal.Model;


import org.junit.jupiter.api.Test;

import com.cognizant.WebPortal.Model.AuthResponse;

class AuthResponseTest {

	@Test
	void test() {
		AuthResponse auth=new AuthResponse();
	}

}
